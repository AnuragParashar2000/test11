(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_61af54._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_61af54._.js",
  "chunks": [
    "static/chunks/[root of the server]__7db745._.css",
    "static/chunks/src_app_layout_tsx_20a9fc._.js"
  ],
  "source": "dynamic"
});
